import random
from csv import reader
import numpy as np
from string import ascii_uppercase
import time
start_time = time.time()

def vienas_nn(x_set, weights):
    svsuma = weights[0]
    for i, x_val in enumerate(x_set):
        svsuma = svsuma + x_val*weights[i+1]
    return sigmoide(svsuma)

def sigmoide(x_val):
    return 1/(1+np.exp(-x_val+10))

def vien_sluoksnis_t(x_set, weights):
    eil=len(weights)
    neuron_answer = []
    for i in range(int(eil/4)):
        neuron_answer.append(vienas_nn(x_set, weights[i]))
    return neuron_answer

def sklaidos_atvirkstinis_sklidimas_train_set(x_set, weights, nn_tans_set):
    iter_max = 500
    eps = 1e-6
    iter_nr = 1
    derr = []
    step = 0.5
    test_set_el_sk = len(x_set)
    test_set_el_nr = 0
    binary_set = x_set[test_set_el_nr]
    nn_tans = nn_tans_set[test_set_el_nr] 
    x_1 = [1] + binary_set
    for i in range(len(nn_tans)):
        derr.append(1e10)
    testi = 1
    while testi:
        testi = 0
        for test_set_el_nr in range(test_set_el_sk):
            binary_set = x_set[test_set_el_nr]
            nn_tans = nn_tans_set[test_set_el_nr]
            x_1 = [1] + binary_set
            nn_fans=vien_sluoksnis_t(binary_set,weights) 
            for i, nnt in enumerate(nn_tans):
                derr[i] = (nnt - nn_fans[i]) * nn_fans[i] * (1-nn_fans[i])
                for j in range(len(weights[0])):
                    weights[i][j] = weights[i][j] + derr[i]*x_1[j]*step
            abs_derr = max([abs(el) for el in derr])
            testi_lok = (abs_derr > eps) and (iter_nr < iter_max)
            testi = testi or testi_lok
        iter_nr +=1
    return weights

weights = []
SDM = [81+1, 104]
for i in range(SDM[1]):
    weights.append([])
    for j in range (SDM[0]):
        weights[i].append(random.uniform(0.1, 0.4))

x_set = []
K = 0
ADDRESS = "..\\DNT\\Letters\\"
for i in range(1, 27):
    for j in range(0, 4):
        listas = []
        NEW_ADDRESS = ADDRESS + F"{i}_{j}.csv"
        with open(NEW_ADDRESS, 'r', encoding="utf8") as csv_file:
            csv_reader = reader(csv_file, delimiter = ';')
            for row in csv_reader:
                listas = listas + row
            x_set.append(listas)
            for m in range(0, len(x_set[0])):
                x_set[K][m] = int(x_set[K][m])
            K = K+1

L = -1
nn_tans_set = []
for i in range(104):
    if i % 4 == 0:
        L = L+1
    nn_tans_set.append([])
    for k in range(26):
        if L == k:
            nn_tans_set[i].append(1)
        else:
            nn_tans_set[i].append(0)

new_weights = sklaidos_atvirkstinis_sklidimas_train_set(x_set, weights, nn_tans_set)

#print("Išmokyti variantai:\n")
#M = 0
#PERCENTAGE_1 = 0
#for i in range(26):
    #for j in range(0, 4):
        #print(F"{ascii_uppercase[i]}_{j}:")
        #print(F"Labiausiai sužadintas neuronas: raidės {ascii_uppercase[vien_sluoksnis_t(x_set[M], new_weights).index(max(vien_sluoksnis_t(x_set[M], new_weights)))]}, su reikšme {round(max(vien_sluoksnis_t(x_set[M], new_weights)), 5)}")
        #if i == vien_sluoksnis_t(x_set[M], new_weights).index(max(vien_sluoksnis_t(x_set[M], new_weights))):
            #PERCENTAGE_1 = PERCENTAGE_1 + 1
        #M = M+1
#PERCENTAGE_1 = PERCENTAGE_1*1.0/104*100
#print(F"\nPrograma išmokytų variantų atveju buvo {PERCENTAGE_1:.2f}% taikli")

N = 0
x_set_test = []
ADDRESS = "..\\DNT\\Letters_Test\\"
print("\n\nTestiniai variantai:\n")
for i in range(1, 27):
    listasTest = []
    NEW_ADDRESS = ADDRESS + F"{i}_t.csv"
    with open(NEW_ADDRESS, 'r',  encoding="utf-8") as csv_file:
        csv_reader = reader(csv_file, delimiter = ';')
        for row in csv_reader:
            listasTest = listasTest + row
        x_set_test.append(listasTest)
        for u in range(0, len(x_set_test[0])):
            x_set_test[N][u] = int(x_set_test[N][u])
        N = N+1

Z = 0
PERCENTAGE_2 = 0
for i in range(26):
    print(F"{ascii_uppercase[i]}:")
    print(F"Labiausiai sužadintas neuronas: raidės {ascii_uppercase[vien_sluoksnis_t(x_set_test[Z], new_weights).index(max(vien_sluoksnis_t(x_set_test[Z], new_weights)))]}, su reikšme {round(max(vien_sluoksnis_t(x_set_test[Z], new_weights)), 5)}")
    if i == vien_sluoksnis_t(x_set_test[Z], new_weights).index(max(vien_sluoksnis_t(x_set_test[Z], new_weights))):
        PERCENTAGE_2 = PERCENTAGE_2 + 1
    Z = Z+1
PERCENTAGE_2 = PERCENTAGE_2*1.0/26*100
print(F"\nPrograma testinių variantų atveju buvo {PERCENTAGE_2:.2f}% taikli")
print(F"--- {time.time()-start_time:.2f} seconds ---")
